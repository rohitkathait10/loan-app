<h2>New Contact Form Submission</h2>

<p><strong>Name:</strong> {{ $name }}</p>
<p><strong>Phone:</strong> {{ $phone }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Message:</strong><br>{{ $user_message }}</p>
